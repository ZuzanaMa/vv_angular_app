import { Component } from '@angular/core';
import { ITransaction, TransactionsServiceService } from 'src/app/api/transactions-service.service';

@Component({
  selector: 'app-basic-account-list',
  templateUrl: './basic-account-list.component.html',
  styleUrls: ['./basic-account-list.component.css']
})
export class BasicAccountListComponent {
public transactionList: ITransaction[] = [];

  constructor(private transactionService: TransactionsServiceService ){
    this.transactionService.getTransactions$().subscribe((response) => {
      this.transactionList = response.data;
    }) 
  }
}
