import { Component } from '@angular/core';

@Component({
  selector: 'app-withdrawal-detail',
  templateUrl: './withdrawal-detail.component.html',
  styleUrls: ['./withdrawal-detail.component.css']
})
export class WithdrawalDetailComponent {

}
