import { TransactionTypePipe } from './transaction-type.pipe';

describe('TransactionTypePipe', () => {
  it('create an instance', () => {
    const pipe = new TransactionTypePipe();
    expect(pipe).toBeTruthy();
  });
});
