module.exports = {
    "/api": {
    target: "http://localhost:5000/",
    changeOrigin: true,
    secure: false,
    }
   }
   